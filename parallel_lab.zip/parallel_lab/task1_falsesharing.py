import ctypes
import multiprocessing as mp
from multiprocessing import shared_memory
from harness import emit_verify_tag, run_benchmark


def fs_worker(shm_name: str, slot_idx: int, iters: int) -> None:
    shm = shared_memory.SharedMemory(name=shm_name)
    arr = (ctypes.c_uint64 * 512).from_buffer(shm.buf)
    acc = arr[slot_idx]
    mask = 0xFFFFFFFFFFFFFFFF
    mult = 6364136223846793005
    for i in range(iters):
        acc = (acc * mult + (i | 1)) & mask
        arr[slot_idx] = acc
    del arr
    shm.close()


def run_fs_trial(p: int, stride: int, total_ops: int = 24_000_000) -> None:
    shm = shared_memory.SharedMemory(create=True, size=4096)
    try:
        iters_per_worker = total_ops // p
        procs = [
            mp.Process(target=fs_worker, args=(shm.name, t * stride, iters_per_worker))
            for t in range(p)
        ]
        for proc in procs:
            proc.start()
        for proc in procs:
            proc.join()
    finally:
        shm.close()
        shm.unlink()


if __name__ == "__main__":
    # ВПИШИТЕ СЮДА ТОТ ЖЕ STUDENT ID, ЧТО И В PHASE 0!
    STUDENT_ID = 230103234
    P_PHYS = 8
    P_LOG = 8
    TOTAL_OPS = 24_000_000

    print("=== EXPERIMENT 1A: Stride Sweep at p = P_phys (8) ===")
    print(f"{'Stride':>6} | {'Bytes':>6} | {'Median (ms)':>12} | {'IQR (ms)':>10} | {'Throughput (Mops/s)':>20}")
    print("-" * 66)

    strides = [1, 2, 4, 8, 16, 32]
    med_stride_1 = 0.0
    med_stride_16 = 0.0

    for s in strides:
        stats = run_benchmark(
            lambda: run_fs_trial(P_PHYS, s, TOTAL_OPS), warmup_runs=2, timed_runs=7
        )
        mops = (TOTAL_OPS / 1e6) / (stats.median_ms / 1000.0)
        print(f"{s:>6} | {s*8:>6} | {stats.median_ms:>12.4f} | {stats.iqr_ms:>10.4f} | {mops:>20.2f}")
        if s == 1:
            med_stride_1 = stats.median_ms
        elif s == 16:
            med_stride_16 = stats.median_ms

    print("\n=== EXPERIMENT 1B: Process Scaling Sweep (stride=1 vs stride=16) ===")
    p_values = [1, 2, 4, 8]
    for s in [1, 16]:
        print(f"\n--- Stride = {s} ({s*8} bytes separation) ---")
        print(f"{'p':>4} | {'Median (ms)':>12} | {'Speedup S_p':>12} | {'Efficiency E_p':>15} | {'Karp-Flatt e(p)':>16}")
        print("-" * 70)
        t1 = 0.0
        for p in p_values:
            stats = run_benchmark(
                lambda: run_fs_trial(p, s, TOTAL_OPS), warmup_runs=2, timed_runs=7
            )
            if p == 1:
                t1 = stats.median_ms
                sp = 1.0
                ep = 1.0
                ef_str = "N/A"
            else:
                sp = t1 / stats.median_ms
                ep = sp / p
                ef = ((1.0 / sp) - (1.0 / p)) / (1.0 - (1.0 / p))
                ef_str = f"{ef:.4f}"
            print(f"{p:>4} | {stats.median_ms:>12.4f} | {sp:>12.4f} | {ep:>15.4f} | {ef_str:>16}")

    print("\n" + emit_verify_tag("PHASE1", STUDENT_ID, med_stride_1, med_stride_16))