import multiprocessing as mp
import time
from harness import emit_verify_tag, run_benchmark


def calibrate_timer(iterations: int = 2_000_000) -> float:
    t0 = time.perf_counter_ns()
    for _ in range(iterations):
        time.perf_counter_ns()
    t1 = time.perf_counter_ns()
    return (t1 - t0) / iterations


if __name__ == "__main__":
    # ВПИШИТЕ СЮДА ВАШ STUDENT ID (ТОЛЬКО ЦИФРЫ)
    STUDENT_ID = 230103234
    ITERS = 2_000_000

    p_log = mp.cpu_count()
    print(f"Logical CPUs (P_log): {p_log}")

    # Замеряем через run_benchmark для статистики (в мс) и отдельно среднюю задержку (в нс)
    stats = run_benchmark(lambda: calibrate_timer(ITERS), warmup_runs=2, timed_runs=5)
    avg_ns = (stats.median_ms * 1e6) / ITERS

    print(f"Timer loop median: {stats.median_ms:.4f} ms (IQR: {stats.iqr_ms:.4f} ms)")
    print(f"Average call latency: {avg_ns:.4f} ns")
    print(emit_verify_tag("PHASE0", STUDENT_ID, avg_ns, stats.median_ms))