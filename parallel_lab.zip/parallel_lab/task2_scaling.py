import math
import multiprocessing as mp
import time
from harness import emit_verify_tag, run_benchmark


def stage_a_serial(n_items: int) -> float:
    limit = int(0.05 * n_items)
    acc = 0.0
    for i in range(limit):
        x = (i + 1) * 1e-4
        for _ in range(12):
            x = math.sin(x) + math.sqrt(abs(x) + 1.0)
        acc += x
    return acc


def stage_b_chunk(args: tuple[int, int]) -> float:
    start, end = args
    acc = 0.0
    for i in range(start, end):
        x = (i + 1) * 1e-5
        for _ in range(35):
            x = x * 0.999999 + math.sin(x)
        acc += x
    return acc


def make_chunks(n_items: int, p: int) -> list[tuple[int, int]]:
    chunk_size = n_items // p
    chunks = []
    for t in range(p):
        s = t * chunk_size
        e = n_items if t == p - 1 else (t + 1) * chunk_size
        chunks.append((s, e))
    return chunks


def measure_stage_a_ms(n_items: int, runs: int = 5) -> float:
    samples = []
    for _ in range(runs):
        t0 = time.perf_counter_ns()
        stage_a_serial(n_items)
        t1 = time.perf_counter_ns()
        samples.append((t1 - t0) / 1e6)
    samples.sort()
    return samples[len(samples) // 2]


if __name__ == "__main__":
    # ВПИШИТЕ СЮДА ВАШ STUDENT ID!
    STUDENT_ID = 230103234
    P_LOG = 8
    N_STRONG = 1_600_000
    N0_WEAK = 250_000

    print("=== EXPERIMENT 2A: Strong Scaling (N = 1,600,000) ===")
    t_stage_a_strong = measure_stage_a_ms(N_STRONG, runs=5)
    print(f"Measured Stage A serial time at N={N_STRONG}: {t_stage_a_strong:.4f} ms")
    print(f"{'p':>3} | {'T_p (ms)':>11} | {'IQR (ms)':>9} | {'Speedup S_p':>12} | {'Efficiency E_p':>15}")
    print("-" * 62)

    t1_strong = 0.0
    s_plog_strong = 0.0
    strong_speedups = {}

    for p in range(1, P_LOG + 1):
        chunks = make_chunks(N_STRONG, p)
        with mp.Pool(processes=p) as pool:
            # прогрев пула
            pool.map(stage_b_chunk, chunks)
            stats = run_benchmark(
                lambda: (stage_a_serial(N_STRONG), pool.map(stage_b_chunk, chunks)),
                warmup_runs=2,
                timed_runs=5,
            )
        if p == 1:
            t1_strong = stats.median_ms
        sp = t1_strong / stats.median_ms
        ep = sp / p
        strong_speedups[p] = sp
        if p == P_LOG:
            s_plog_strong = sp
        print(f"{p:>3} | {stats.median_ms:>11.4f} | {stats.iqr_ms:>9.4f} | {sp:>12.4f} | {ep:>15.4f}")

    s_frac = t_stage_a_strong / t1_strong
    s_amdahl_inf = 1.0 / s_frac
    s_amdahl_plog = 1.0 / (s_frac + (1.0 - s_frac) / P_LOG)
    print(f"\nSerial fraction s = {s_frac:.4f} ({s_frac*100:.2f}%)")
    print(f"Amdahl theoretical max speedup (p -> inf): {s_amdahl_inf:.4f}")
    print(f"Amdahl theoretical speedup at p={P_LOG}: {s_amdahl_plog:.4f} vs Observed: {s_plog_strong:.4f}")

    # Анализ перегиба P_phys (4 P-cores -> 5th E-core на M1)
    gain_4 = strong_speedups[4] - strong_speedups[3]
    gain_5 = strong_speedups[5] - strong_speedups[4]
    drop_pct = ((gain_4 - gain_5) / gain_4) * 100.0 if gain_4 > 0 else 0.0
    print(f"Marginal speedup p=3->4: +{gain_4:.4f}, p=4->5: +{gain_5:.4f} (Drop: {drop_pct:.2f}%)")

    print("\n=== EXPERIMENT 2B: Weak Scaling (N(p) = p * 250,000) ===")
    print(f"{'p':>3} | {'N(p)':>9} | {'T_stageA (ms)':>13} | {'T_p (ms)':>11} | {'Weak Eff E_p':>13} | {'Gustafson S_p':>14}")
    print("-" * 76)

    t1_weak = 0.0
    s_plog_gustafson = 0.0

    for p in range(1, P_LOG + 1):
        n_p = p * N0_WEAK
        t_a_p = measure_stage_a_ms(n_p, runs=3)
        chunks = make_chunks(n_p, p)
        with mp.Pool(processes=p) as pool:
            pool.map(stage_b_chunk, chunks)
            stats = run_benchmark(
                lambda: (stage_a_serial(n_p), pool.map(stage_b_chunk, chunks)),
                warmup_runs=2,
                timed_runs=5,
            )
        if p == 1:
            t1_weak = stats.median_ms
        ep_weak = t1_weak / stats.median_ms
        alpha = t_a_p / stats.median_ms
        s_gustafson = p - alpha * (p - 1)
        if p == P_LOG:
            s_plog_gustafson = s_gustafson
        print(f"{p:>3} | {n_p:>9} | {t_a_p:>13.4f} | {stats.median_ms:>11.4f} | {ep_weak:>13.4f} | {s_gustafson:>14.4f}")

    print("\n" + emit_verify_tag("PHASE2", STUDENT_ID, s_plog_strong, s_plog_gustafson))