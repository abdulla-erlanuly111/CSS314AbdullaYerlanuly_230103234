import ctypes
import multiprocessing as mp
from multiprocessing import shared_memory
from harness import emit_verify_tag, run_benchmark


def gemm_v1_worker(shm_a: str, shm_b: str, shm_c: str, n: int, row_start: int, row_end: int) -> None:
    sa = shared_memory.SharedMemory(name=shm_a)
    sb = shared_memory.SharedMemory(name=shm_b)
    sc = shared_memory.SharedMemory(name=shm_c)
    sz = n * n
    a = (ctypes.c_double * sz).from_buffer(sa.buf)
    b = (ctypes.c_double * sz).from_buffer(sb.buf)
    c = (ctypes.c_double * sz).from_buffer(sc.buf)

    for i in range(row_start, row_end):
        i_off = i * n
        for j in range(n):
            dot = 0.0
            for k in range(n):
                dot += a[i_off + k] * b[k * n + j]
            c[i_off + j] = dot

    del a, b, c
    sa.close(); sb.close(); sc.close()


def gemm_v2_worker(shm_a: str, shm_b: str, shm_c: str, n: int, row_start: int, row_end: int) -> None:
    sa = shared_memory.SharedMemory(name=shm_a)
    sb = shared_memory.SharedMemory(name=shm_b)
    sc = shared_memory.SharedMemory(name=shm_c)
    sz = n * n
    a = (ctypes.c_double * sz).from_buffer(sa.buf)
    b = (ctypes.c_double * sz).from_buffer(sb.buf)
    c = (ctypes.c_double * sz).from_buffer(sc.buf)

    for i in range(row_start, row_end):
        i_off = i * n
        for j in range(n):
            c[i_off + j] = 0.0
        for k in range(n):
            a_ik = a[i_off + k]
            k_off = k * n
            for j in range(n):
                c[i_off + j] += a_ik * b[k_off + j]

    del a, b, c
    sa.close(); sb.close(); sc.close()


def gemm_v3_worker(shm_a: str, shm_b: str, shm_c: str, n: int, row_start: int, row_end: int, bs: int) -> None:
    sa = shared_memory.SharedMemory(name=shm_a)
    sb = shared_memory.SharedMemory(name=shm_b)
    sc = shared_memory.SharedMemory(name=shm_c)
    sz = n * n
    a = (ctypes.c_double * sz).from_buffer(sa.buf)
    b = (ctypes.c_double * sz).from_buffer(sb.buf)
    c = (ctypes.c_double * sz).from_buffer(sc.buf)

    for i in range(row_start, row_end):
        i_off = i * n
        for j in range(n):
            c[i_off + j] = 0.0

    for ii in range(row_start, row_end, bs):
        i_max = min(ii + bs, row_end)
        for kk in range(0, n, bs):
            k_max = min(kk + bs, n)
            for jj in range(0, n, bs):
                j_max = min(jj + bs, n)
                for i in range(ii, i_max):
                    i_off = i * n
                    for k in range(kk, k_max):
                        a_ik = a[i_off + k]
                        k_off = k * n
                        for j in range(jj, j_max):
                            c[i_off + j] += a_ik * b[k_off + j]

    del a, b, c
    sa.close(); sb.close(); sc.close()


def run_gemm_parallel(variant: int, shm_a: str, shm_b: str, shm_c: str, n: int, p: int, bs: int = 32) -> None:
    rows_per_worker = n // p
    procs = []
    for t in range(p):
        rs = t * rows_per_worker
        re = n if t == p - 1 else (t + 1) * rows_per_worker
        if variant == 1:
            args = (shm_a, shm_b, shm_c, n, rs, re)
            target = gemm_v1_worker
        elif variant == 2:
            args = (shm_a, shm_b, shm_c, n, rs, re)
            target = gemm_v2_worker
        else:
            args = (shm_a, shm_b, shm_c, n, rs, re, bs)
            target = gemm_v3_worker
        procs.append(mp.Process(target=target, args=args))
    for proc in procs:
        proc.start()
    for proc in procs:
        proc.join()


if __name__ == "__main__":
    # ВПИШИТЕ СЮДА ВАШ STUDENT ID!
    STUDENT_ID = 230103234
    N = 384
    P_PHYS = 8
    TOTAL_FLOPS = 2.0 * (N ** 3)
    BYTE_SIZE = N * N * 8

    sa = shared_memory.SharedMemory(create=True, size=BYTE_SIZE)
    sb = shared_memory.SharedMemory(create=True, size=BYTE_SIZE)
    sc_ref = shared_memory.SharedMemory(create=True, size=BYTE_SIZE)
    sc = shared_memory.SharedMemory(create=True, size=BYTE_SIZE)

    try:
        sz = N * N
        arr_a = (ctypes.c_double * sz).from_buffer(sa.buf)
        arr_b = (ctypes.c_double * sz).from_buffer(sb.buf)
        for idx in range(sz):
            arr_a[idx] = ((idx % 17) - 8) * 0.125
            arr_b[idx] = ((idx % 13) - 6) * 0.25
        del arr_a, arr_b

        print(f"=== PART 3B: Parallel GEMM Optimization (N = {N}, p = {P_PHYS}) ===")

        st_v1 = run_benchmark(
            lambda: run_gemm_parallel(1, sa.name, sb.name, sc.name, N, P_PHYS),
            warmup_runs=1, timed_runs=3
        )
        gflops_v1 = TOTAL_FLOPS / ((st_v1.median_ms / 1000.0) * 1e9)
        print(f"Variant 1 (Naive i-j-k):    {st_v1.median_ms:10.4f} ms | {gflops_v1:.5f} GFLOP/s")

        st_v2 = run_benchmark(
            lambda: run_gemm_parallel(2, sa.name, sb.name, sc_ref.name, N, P_PHYS),
            warmup_runs=1, timed_runs=3
        )
        gflops_v2 = TOTAL_FLOPS / ((st_v2.median_ms / 1000.0) * 1e9)
        print(f"Variant 2 (Reordered i-k-j): {st_v2.median_ms:10.4f} ms | {gflops_v2:.5f} GFLOP/s")

        arr_c_ref = (ctypes.c_double * sz).from_buffer(sc_ref.buf)
        ref_copy = list(arr_c_ref)
        del arr_c_ref

        print("\n=== Variant 3: 10-Point Tile Size (BS) Sweep ===")
        print(f"{'BS':>4} | {'W_tile (KB)':>12} | {'Median (ms)':>12} | {'GFLOP/s':>10} | {'I_tiled (F/B)':>14} | {'Max Diff':>10}")
        print("-" * 76)

        bs_list = [4, 8, 12, 16, 24, 32, 48, 64, 96, 128]
        best_bs = 4
        best_gflops_v3 = 0.0

        for bs in bs_list:
            st_v3 = run_benchmark(
                lambda: run_gemm_parallel(3, sa.name, sb.name, sc.name, N, P_PHYS, bs),
                warmup_runs=1, timed_runs=3
            )
            gf = TOTAL_FLOPS / ((st_v3.median_ms / 1000.0) * 1e9)
            w_tile_kb = (3.0 * bs * bs * 8.0) / 1024.0
            i_tiled = bs / 12.0

            arr_c = (ctypes.c_double * sz).from_buffer(sc.buf)
            max_diff = max(abs(arr_c[k] - ref_copy[k]) for k in range(sz))
            del arr_c

            if gf > best_gflops_v3:
                best_gflops_v3 = gf
                best_bs = bs

            print(f"{bs:>4} | {w_tile_kb:>12.2f} | {st_v3.median_ms:>12.4f} | {gf:>10.5f} | {i_tiled:>14.4f} | {max_diff:>10.2e}")

        print(f"\nOptimal Tile Size BS* = {best_bs} -> Peak GFLOP/s = {best_gflops_v3:.5f}")
        print(emit_verify_tag("PHASE3", STUDENT_ID, gflops_v1, best_gflops_v3))

    finally:
        sa.close(); sa.unlink()
        sb.close(); sb.unlink()
        sc_ref.close(); sc_ref.unlink()
        sc.close(); sc.unlink()