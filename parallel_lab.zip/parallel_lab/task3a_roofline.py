import multiprocessing as mp
from multiprocessing import shared_memory
from harness import run_benchmark


def bw_worker(shm_a_name: str, shm_b_name: str, start: int, end: int) -> None:
    shm_a = shared_memory.SharedMemory(name=shm_a_name)
    shm_b = shared_memory.SharedMemory(name=shm_b_name)
    mv_a = memoryview(shm_a.buf)
    mv_b = memoryview(shm_b.buf)
    # Аппаратное векторное копирование среза (1 чтение + 1 запись = 2 байта трафика DRAM на байт)
    mv_a[start:end] = mv_b[start:end]
    mv_a.release()
    mv_b.release()
    shm_a.close()
    shm_b.close()


def run_bw_trial(p: int, buf_bytes: int = 96_000_000) -> None:
    shm_a = shared_memory.SharedMemory(create=True, size=buf_bytes)
    shm_b = shared_memory.SharedMemory(create=True, size=buf_bytes)
    try:
        chunk = buf_bytes // p
        procs = []
        for t in range(p):
            s = t * chunk
            e = buf_bytes if t == p - 1 else (t + 1) * chunk
            procs.append(mp.Process(target=bw_worker, args=(shm_a.name, shm_b.name, s, e)))
        for proc in procs:
            proc.start()
        for proc in procs:
            proc.join()
    finally:
        shm_a.close()
        shm_a.unlink()
        shm_b.close()
        shm_b.unlink()


def fma_worker(iters: int) -> float:
    # 16 развернутых локальных скаляров для насыщения диспетчера и FP-конвейера
    x0 = 1.0001; x1 = 1.0002; x2 = 1.0003; x3 = 1.0004
    x4 = 1.0005; x5 = 1.0006; x6 = 1.0007; x7 = 1.0008
    x8 = 1.0009; x9 = 1.0010; x10 = 1.0011; x11 = 1.0012
    x12 = 1.0013; x13 = 1.0014; x14 = 1.0015; x15 = 1.0016
    a = 0.999999
    b = 0.000001
    for _ in range(iters):
        x0 = x0 * a + b; x1 = x1 * a + b; x2 = x2 * a + b; x3 = x3 * a + b
        x4 = x4 * a + b; x5 = x5 * a + b; x6 = x6 * a + b; x7 = x7 * a + b
        x8 = x8 * a + b; x9 = x9 * a + b; x10 = x10 * a + b; x11 = x11 * a + b
        x12 = x12 * a + b; x13 = x13 * a + b; x14 = x14 * a + b; x15 = x15 * a + b
    return x0 + x1 + x2 + x3 + x4 + x5 + x6 + x7 + x8 + x9 + x10 + x11 + x12 + x13 + x14 + x15


def run_fma_trial(p: int, flops_per_worker: int = 80_000_000) -> None:
    # Каждая итерация делает 16 FMA = 32 FLOP
    iters = flops_per_worker // 32
    procs = [mp.Process(target=fma_worker, args=(iters,)) for _ in range(p)]
    for proc in procs:
        proc.start()
    for proc in procs:
        proc.join()


if __name__ == "__main__":
    P_PHYS = 8
    BUF_BYTES = 96_000_000
    FLOPS_PER_WORKER = 80_000_000

    print("=== PART 3A: Empirical Machine Roofline (p = 8) ===")
    bw_stats = run_benchmark(
        lambda: run_bw_trial(P_PHYS, BUF_BYTES), warmup_runs=2, timed_runs=7
    )
    # 2 * 96 MB трафика DRAM
    bw_sustained = (2.0 * BUF_BYTES) / ((bw_stats.median_ms / 1000.0) * 1e9)
    print(f"DRAM Copy Median: {bw_stats.median_ms:.4f} ms (IQR: {bw_stats.iqr_ms:.4f} ms)")
    print(f"Sustained DRAM Bandwidth (BW_sustained): {bw_sustained:.4f} GB/s")

    fma_stats = run_benchmark(
        lambda: run_fma_trial(P_PHYS, FLOPS_PER_WORKER), warmup_runs=2, timed_runs=7
    )
    total_flops = P_PHYS * FLOPS_PER_WORKER
    p_sustained = total_flops / ((fma_stats.median_ms / 1000.0) * 1e9)
    ridge_point = p_sustained / bw_sustained

    print(f"Unrolled FMA Median: {fma_stats.median_ms:.4f} ms (IQR: {fma_stats.iqr_ms:.4f} ms)")
    print(f"Sustained Python Compute Ceiling (P_sustained): {p_sustained:.4f} GFLOP/s")
    print(f"Empirical Ridge Point (I* = P / BW): {ridge_point:.6f} FLOPs/Byte")