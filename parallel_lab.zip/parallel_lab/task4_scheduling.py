import math
import multiprocessing as mp
import time
from harness import emit_verify_tag, run_benchmark


def heavy_item(i: int) -> float:
    k = 1 + (i // 60) ** 2
    x = (i + 1) * 1e-4
    for _ in range(k):
        x = math.sin(x) + math.cos(x) + math.sqrt(abs(x) + 1.0)
    return x


def worker_block(t: int, p: int, n: int, times_arr: mp.Array) -> None:
    t0 = time.perf_counter_ns()
    chunk = n // p
    start = t * chunk
    end = n if t == p - 1 else (t + 1) * chunk
    acc = 0.0
    for i in range(start, end):
        acc += heavy_item(i)
    t1 = time.perf_counter_ns()
    times_arr[t] = (t1 - t0) / 1e6


def worker_cyclic(t: int, p: int, n: int, times_arr: mp.Array) -> None:
    t0 = time.perf_counter_ns()
    acc = 0.0
    for i in range(t, n, p):
        acc += heavy_item(i)
    t1 = time.perf_counter_ns()
    times_arr[t] = (t1 - t0) / 1e6


def worker_dynamic(t: int, n: int, chunk_size: int, counter: mp.RawValue, lock: mp.Lock, times_arr: mp.Array) -> None:
    t0 = time.perf_counter_ns()
    acc = 0.0
    while True:
        with lock:
            start = counter.value
            if start >= n:
                break
            counter.value = start + chunk_size
        end = min(start + chunk_size, n)
        for i in range(start, end):
            acc += heavy_item(i)
    t1 = time.perf_counter_ns()
    times_arr[t] = (t1 - t0) / 1e6


def run_strategy(strategy: str, p: int, n: int, chunk_size: int = 16) -> tuple[float, float]:
    times_arr = mp.Array("d", p, lock=False)
    procs = []
    if strategy == "block":
        procs = [mp.Process(target=worker_block, args=(t, p, n, times_arr)) for t in range(p)]
    elif strategy == "cyclic":
        procs = [mp.Process(target=worker_cyclic, args=(t, p, n, times_arr)) for t in range(p)]
    else:
        counter = mp.RawValue("i", 0)
        lock = mp.Lock()
        procs = [
            mp.Process(target=worker_dynamic, args=(t, n, chunk_size, counter, lock, times_arr))
            for t in range(p)
        ]

    t0 = time.perf_counter_ns()
    for proc in procs:
        proc.start()
    for proc in procs:
        proc.join()
    t1 = time.perf_counter_ns()

    wall_ms = (t1 - t0) / 1e6
    w_times = [times_arr[t] for t in range(p)]
    mean_t = sum(w_times) / p
    lam = max(w_times) / mean_t if mean_t > 0 else 1.0
    return wall_ms, lam


def bench_strategy(strategy: str, p: int, n: int, chunk_size: int = 16, warmup: int = 1, runs: int = 3) -> tuple[float, float]:
    for _ in range(warmup):
        run_strategy(strategy, p, n, chunk_size)
    samples = [run_strategy(strategy, p, n, chunk_size) for _ in range(runs)]
    samples.sort(key=lambda x: x[0])
    return samples[len(samples) // 2]


if __name__ == "__main__":
    # ВПИШИТЕ СЮДА ВАШ STUDENT ID!
    STUDENT_ID = 230103234
    N = 12_000
    P_PHYS = 8

    print(f"=== PHASE 4: Skewed Workload Scheduling & Load Imbalance (N = {N}, p = {P_PHYS}) ===")
    print(f"{'Strategy':<24} | {'T_wall (ms)':>12} | {'Imbalance (lambda)':>18}")
    print("-" * 60)

    t_block, lam_block = bench_strategy("block", P_PHYS, N)
    print(f"{'1. Static Block':<24} | {t_block:>12.4f} | {lam_block:>18.4f}")

    t_cyclic, lam_cyclic = bench_strategy("cyclic", P_PHYS, N)
    print(f"{'2. Static Cyclic':<24} | {t_cyclic:>12.4f} | {lam_cyclic:>18.4f}")

    chunk_sizes = [1, 4, 16, 64, 256, 1024]
    best_c = 1
    best_t_dyn = float("inf")

    for c in chunk_sizes:
        t_dyn, lam_dyn = bench_strategy("dynamic", P_PHYS, N, chunk_size=c)
        label = f"3. Dynamic (C={c})"
        print(f"{label:<24} | {t_dyn:>12.4f} | {lam_dyn:>18.4f}")
        if t_dyn < best_t_dyn:
            best_t_dyn = t_dyn
            best_c = c

    print(f"\nOptimal Dynamic Chunk Size C* = {best_c} -> T_wall = {best_t_dyn:.4f} ms")
    print(emit_verify_tag("PHASE4", STUDENT_ID, t_block, best_t_dyn))